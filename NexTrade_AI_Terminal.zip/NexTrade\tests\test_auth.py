import pytest
from app import app
from models import db, User, OTPVerification
from werkzeug.security import generate_password_hash
import json

@pytest.fixture
def client():
    app.config['TESTING'] = True
    # Use memory database for tests
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    
    with app.test_client() as client:
        with app.app_context():
            db.create_all()
        yield client
        with app.app_context():
            db.drop_all()

def test_register_success(client):
    response = client.post('/api/auth/register', json={
        "full_name": "Test User",
        "email": "test@example.com",
        "password": "Pass123!"
    })
    
    assert response.status_code == 201
    data = json.loads(response.data)
    assert "Registration successful" in data['message']
    
    with app.app_context():
        user = User.query.filter_by(email="test@example.com").first()
        assert user is not None
        assert user.is_verified == False
        
        # Check OTP created
        otp = OTPVerification.query.filter_by(user_id=user.id).first()
        assert otp is not None
        assert len(otp.otp_code) == 6

def test_register_weak_password(client):
    response = client.post('/api/auth/register', json={
        "full_name": "Test User",
        "email": "test@example.com",
        "password": "weak"
    })
    assert response.status_code == 400
    assert "Password must be at least" in json.loads(response.data)['error']

def test_verify_otp_success(client):
    # Setup unverified user with OTP
    with app.app_context():
        user = User(full_name="Verify Me", email="verify@test.com", password_hash="hash", auth_provider="local", is_verified=False)
        db.session.add(user)
        db.session.commit()
        
        otp = OTPVerification(user_id=user.id, otp_code="123456", expires_at=db.func.datetime(db.func.current_timestamp(), '+10 minutes'))
        db.session.add(otp)
        db.session.commit()
        
    response = client.post('/api/auth/verify-otp', json={
        "email": "verify@test.com",
        "otp_code": "123456"
    })
    
    assert response.status_code == 200
    
    with app.app_context():
        # Check db updated
        user = User.query.filter_by(email="verify@test.com").first()
        assert user.is_verified == True

def test_verify_otp_invalid_code(client):
    with app.app_context():
        user = User(full_name="Verify Me", email="verify2@test.com", password_hash="hash", auth_provider="local", is_verified=False)
        db.session.add(user)
        db.session.commit()
        
        otp = OTPVerification(user_id=user.id, otp_code="123456", expires_at=db.func.datetime(db.func.current_timestamp(), '+10 minutes'))
        db.session.add(otp)
        db.session.commit()

    response = client.post('/api/auth/verify-otp', json={
        "email": "verify2@test.com",
        "otp_code": "999999" # Wrong code
    })
    assert response.status_code == 400
    assert "Invalid OTP" in json.loads(response.data)['error']

def test_login_success(client):
    # Setup verified user
    with app.app_context():
        pwd_hash = generate_password_hash("Password123")
        user = User(full_name="Login User", email="login@test.com", password_hash=pwd_hash, auth_provider="local", is_verified=True)
        db.session.add(user)
        db.session.commit()
        
    response = client.post('/api/auth/login', json={
        "email": "login@test.com",
        "password": "Password123"
    })
    
    assert response.status_code == 200
    assert "Login successful" in json.loads(response.data)['message']

def test_login_unverified(client):
    # Setup unverified user
    with app.app_context():
        pwd_hash = generate_password_hash("Password123")
        user = User(full_name="Unverified User", email="unverified@test.com", password_hash=pwd_hash, auth_provider="local", is_verified=False)
        db.session.add(user)
        db.session.commit()
        
    response = client.post('/api/auth/login', json={
        "email": "unverified@test.com",
        "password": "Password123"
    })
    
    assert response.status_code == 403
    data = json.loads(response.data)
    assert "verify your email" in data['error']
    assert data['requires_verification'] == True
