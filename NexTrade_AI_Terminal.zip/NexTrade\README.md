# NexTrade | AI Stock Predictor

NexTrade is a modern full-stack web application designed to predict stock market trends. Leveraging Machine Learning (Random Forest) and technical indicators (SMA, RSI, Bollinger Bands), it analyzes historical stock data from Yahoo Finance to generate predictive signals (BUY/SELL/HOLD).

## Features
- **AI-Powered Predictions**: Uses a trained ML model to forecast whether a stock's closing price will increase or decrease.
- **Trading Signals**: Evaluates predictions with probability scores to issue actionable BUY or SELL signals.
- **Interactive Charts**: Employs Plotly.js to render candlestick charts and moving averages intuitively.
- **Modern UI**: Designed with an ultra-premium dark theme, glassmorphism, and responsive layout.

## Project Structure
```text
.
├── app.py                     # Main Flask Application
├── ml/
│   ├── data_acquisition.py    # Fetches data from yfinance & preprocesses 
│   ├── model.py               # ML (Random Forest) training & inference
│   └── signal_generation.py   # Signal logic (BUY, SELL, HOLD)
├── models/                    # Saved joblib models
├── static/
│   ├── css/
│   │   └── style.css          # Core styles
│   └── js/
│       └── main.js            # Frontend interactions and Plotly rendering
├── templates/
│   └── index.html             # Dashboard View
├── tests/
│   ├── test_model.py          # Unit tests for data and signals
│   └── test_api.py            # Integration tests for Flask endpoints
└── requirements.txt           # Python dependencies
```

## Setup & Installation

**Prerequisites:** Python 3.9+

**1. Create a virtual environment & Install dependencies:**
```bash
python -m venv venv
# Windows:
.\venv\Scripts\Activate.ps1
# Mac/Linux:
source venv/bin/activate

pip install -r requirements.txt
```

**2. Run the Server:**
```bash
python app.py
```
> The application will start at `http://localhost:5000`

## Using the Application
Navigate to the dashboard and enter any valid valid stock ticker (e.g., AAPL for Apple, TSLA for Tesla) in the search bar. Click **Analyze** to automatically train (if needed) and infer the market trend.

## Local Dataset Support
You can now use your own CSV datasets instead of fetching from Yahoo Finance:
1. Create a folder named `data/` in the project root (already created).
2. Place your CSV file inside and name it `{SYMBOL}.csv` (e.g., `AAPL.csv`).
3. Ensure the CSV has a `Date` column and at least `Open`, `High`, `Low`, `Close`, and `Volume` columns.
4. When you search for that symbol in the dashboard, the app will automatically load your local file.

## Testing
Run the automated test suite with `pytest`:
```bash
pytest tests/
```

## Deployment Notes
For cloud deployment (e.g., Heroku, AWS Elastic Beanstalk), a `Procfile` should be created pointing to `app:app` via Gunicorn.
```text
web: gunicorn app:app
```
