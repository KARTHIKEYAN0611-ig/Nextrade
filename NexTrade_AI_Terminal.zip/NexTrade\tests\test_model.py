import pytest
import pandas as pd
from ml.engine import StockPredictor

def test_technical_indicators():
    predictor = StockPredictor(model_dir='test_models')
    # Create dummy data long enough for technical indicators (needs at least 50 points for SMA_50)
    data = {
        'Open': [10 + i for i in range(60)],
        'High': [11 + i for i in range(60)],
        'Low': [9 + i for i in range(60)],
        'Close': [10 + i for i in range(60)],
        'Volume': [1000]*60
    }
    df = pd.DataFrame(data)
    processed = predictor.preprocess(df)
    # Since prices are rising, RSI should be high
    assert processed['RSI'].iloc[-1] > 80
    assert 'SMA_20' in processed.columns
    assert 'SMA_50' in processed.columns

def test_preprocess_data():
    predictor = StockPredictor(model_dir='test_models')
    data = {
        'Open': [10]*30,
        'High': [11]*30,
        'Low': [9]*30,
        'Close': [10]*30,
        'Volume': [1000]*30
    }
    df = pd.DataFrame(data)
    processed = predictor.preprocess(df)
    
    # Check if necessary columns are added
    assert 'SMA_20' in processed.columns
    assert 'RSI' in processed.columns
    assert 'Daily_Return' in processed.columns
