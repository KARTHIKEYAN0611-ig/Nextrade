import os
import numpy as np
import pandas as pd
from stable_baselines3 import PPO
from stable_baselines3.common.vec_env import DummyVecEnv
from .trading_env import TradingEnv
from .engine import StockPredictor

class RLPredictor:
    def __init__(self, model_dir='models'):
        self.model_dir = model_dir
        self.base_predictor = StockPredictor()
        
        if not os.path.exists(self.model_dir):
            os.makedirs(self.model_dir)

    def _get_model_path(self, symbol, interval):
        return os.path.join(self.model_dir, f"{symbol}_{interval}_ppo.zip")

    def train(self, symbol, interval="1d", total_timesteps=10000):
        """Train a PPO model for a specific symbol and interval."""
        # RL needs lots of data, so we fetch as much as possible for the interval
        df = self.base_predictor.fetch_data(symbol, period="5y", interval=interval)
        if df is None: return False
        
        processed = self.base_predictor.preprocess_rl(df)
        if processed is None: return False

        # Create environment
        env = DummyVecEnv([lambda: TradingEnv(processed)])

        # Initialize PPO
        # MLP Policy is suitable for tabular indicator data
        model = PPO("MlpPolicy", env, verbose=0, learning_rate=0.0003, n_steps=2048)
        
        # Train
        model.learn(total_timesteps=total_timesteps)
        
        # Save
        model_path = self._get_model_path(symbol, interval)
        model.save(model_path)
        
        return True

    def get_signal(self, symbol, interval="1d"):
        """Generate a trading signal (BUY/SELL/HOLD) using the trained RL model."""
        raw_df = self.base_predictor.fetch_data(symbol, period="1mo", interval=interval)
        if raw_df is None: return {"error": "Insufficient data"}

        processed = self.base_predictor.preprocess_rl(raw_df)
        if processed is None or len(processed) < 10: 
            return {"error": "Not enough data for RL assessment"}

        model_path = self._get_model_path(symbol, interval)
        if not os.path.exists(model_path):
            # If no RL model exists, fallback to baseline or trigger auto-train (short version)
            success = self.train(symbol, interval=interval, total_timesteps=2000)
            if not success: return {"error": "RL model training failed"}

        model = PPO.load(model_path)
        
        # To get a prediction, we need the current observation
        # We'll use the last 'lookback_window_size' rows from processed
        # Note: In our TradingEnv, we used window_size=5
        lookback = 5
        window = processed.iloc[-lookback:]
        obs_data = window.drop(columns=['Date'], errors='ignore').values.flatten()
        
        # Mock the balance/shares info for "prediction" mode
        # In a real setup, this would be the actual account state
        account_info = np.array([1.0, 0, 0.5]) # Normalized balance, shares, cost basis
        obs = np.append(obs_data, account_info).astype(np.float32)

        action, _states = model.predict(obs, deterministic=True)
        
        signals = {0: "HOLD", 1: "BUY", 2: "SELL"}
        return {
            "signal": signals[int(action)],
            "algorithm": "PPO Reinforcement Learning",
            "symbol": symbol,
            "interval": interval
        }
