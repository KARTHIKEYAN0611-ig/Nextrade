import gymnasium as gym
from gymnasium import spaces
import numpy as np
import pandas as pd

class TradingEnv(gym.Env):
    """A custom stock trading environment for Gymnasium."""
    metadata = {'render_modes': ['human']}

    def __init__(self, df, initial_balance=10000, lookback_window_size=5):
        super(TradingEnv, self).__init__()

        self.df = df.reset_index()
        self.initial_balance = initial_balance
        self.lookback_window_size = lookback_window_size

        # Actions: 0 = Hold, 1 = Buy, 2 = Sell
        self.action_space = spaces.Discrete(3)

        # Observation space: OHLCV + Indicators + Balance + Shares held + Cost basis
        # We use a flattened array for simplicity in this version
        num_features = len(df.columns)
        self.observation_space = spaces.Box(
            low=-np.inf, high=np.inf, 
            shape=(num_features * lookback_window_size + 3,), 
            dtype=np.float32
        )

    def reset(self, seed=None, options=None):
        super().reset(seed=seed)
        
        self.balance = self.initial_balance
        self.net_worth = self.initial_balance
        self.shares_held = 0
        self.cost_basis = 0
        self.total_shares_sold = 0
        self.total_sales_value = 0
        self.current_step = self.lookback_window_size

        return self._next_observation(), {}

    def _next_observation(self):
        # Get the stock data for the lookback window
        window = self.df.iloc[self.current_step - self.lookback_window_size: self.current_step]
        
        # Flatten indicators/OHLCV
        obs = window.drop(columns=['Date'], errors='ignore').values.flatten()
        
        # Add account info (normalized roughly)
        account_info = np.array([
            self.balance / self.initial_balance,
            self.shares_held,
            self.cost_basis / (self.df['Close'].max() if not self.df.empty else 1)
        ])
        
        return np.append(obs, account_info).astype(np.float32)

    def step(self, action):
        # Execute one time step within the environment
        current_price = self.df.iloc[self.current_step]['Close']
        
        prev_net_worth = self.net_worth
        
        if action == 1: # Buy
            # Buy as many shares as possible
            total_possible = self.balance // current_price
            if total_possible > 0:
                self.cost_basis = (self.cost_basis * self.shares_held + total_possible * current_price) / (self.shares_held + total_possible)
                self.shares_held += total_possible
                self.balance -= total_possible * current_price
                
        elif action == 2: # Sell
            # Sell all shares
            if self.shares_held > 0:
                self.balance += self.shares_held * current_price
                self.total_shares_sold += self.shares_held
                self.total_sales_value += self.shares_held * current_price
                self.shares_held = 0
                self.cost_basis = 0
        
        self.current_step += 1
        
        # Check if we've reached the end of the data
        done = self.current_step >= len(self.df) - 1
        truncated = False # We don't have a fixed time limit other than the data length
        
        self.net_worth = self.balance + self.shares_held * current_price
        
        # Reward: change in net worth
        reward = self.net_worth - prev_net_worth
        
        # Add a small penalty for holding onto a losing position? (Optional)
        # Or a bonus for making a sale at profit?
        
        obs = self._next_observation()
        
        return obs, reward, done, truncated, {}

    def render(self, mode='human'):
        print(f"Step: {self.current_step}, Net Worth: {self.net_worth:.2f}, Balance: {self.balance:.2f}, Shares: {self.shares_held}")
