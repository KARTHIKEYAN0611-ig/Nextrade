document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements - Dashboard
    const searchInput = document.getElementById('symbolInput');
    const searchBtn = document.getElementById('searchBtn');
    const chartPlaceholder = document.getElementById('chartPlaceholder');
    const loadingSpinner = document.getElementById('loading');
    const errorBanner = document.getElementById('errorBanner');

    // Cards
    const valPred = document.getElementById('predictionValue');
    const confPred = document.getElementById('predictionConfidence');
    const valSignal = document.getElementById('signalValue');
    const valSentiment = document.getElementById('sentimentValue');
    const descSentiment = document.getElementById('sentimentDesc');
    const newsSection = document.getElementById('newsSection');
    const headlinesList = document.getElementById('headlinesList');
    const chartTitle = document.getElementById('chartTitle');

    // DOM Elements - Auth Modals
    const loginModal = document.getElementById('loginModal');
    const registerModal = document.getElementById('registerModal');
    const otpModal = document.getElementById('otpModal');
    const authOverlay = document.getElementById('authOverlay');

    // Auth Forms & Buttons
    const showRegisterLink = document.getElementById('showRegister');
    const showLoginLink = document.getElementById('showLogin');

    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const otpForm = document.getElementById('otpForm');

    const loginError = document.getElementById('loginError');
    const registerError = document.getElementById('registerError');
    const otpError = document.getElementById('otpError');

    // Global state
    let registeredEmail = '';

    // Init popular stocks
    fetchPopularStocks();

    // Event Listeners - Auth UI Swapping
    if (showRegisterLink) {
        showRegisterLink.addEventListener('click', (e) => {
            e.preventDefault();
            loginModal.classList.add('hidden');
            registerModal.classList.remove('hidden');
            registerError.classList.add('hidden');
        });
    }

    if (showLoginLink) {
        showLoginLink.addEventListener('click', (e) => {
            e.preventDefault();
            registerModal.classList.add('hidden');
            loginModal.classList.remove('hidden');
            loginError.classList.add('hidden');
        });
    }

    // Event Listeners - Auth Submissions
    if (registerForm) registerForm.addEventListener('submit', handleRegister);
    if (loginForm) loginForm.addEventListener('submit', handleLogin);
    if (otpForm) otpForm.addEventListener('submit', handleOTPVerify);

    document.getElementById('resendOtpBtn')?.addEventListener('click', handleResendOTP);

    // Event Listeners - Dashboard
    searchBtn.addEventListener('click', analyzeStock);
    searchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') analyzeStock();
    });

    async function analyzeStock() {
        const symbol = searchInput.value.trim().toUpperCase();
        if (!symbol) return;

        // Reset UI
        errorBanner.classList.add('hidden');
        loadingSpinner.classList.remove('hidden');
        chartPlaceholder.classList.add('hidden');

        try {
            const response = await fetch(`/api/predict/${symbol}`);
            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.error || "Failed to fetch data.");
            }

            updateDashboard(data);
        } catch (error) {
            showError(error.message);
        } finally {
            loadingSpinner.classList.add('hidden');
        }
    }

    function updateDashboard(data) {
        chartTitle.textContent = `${data.symbol} Market Analysis`;

        // Update Prediction Card
        valPred.textContent = data.prediction;
        valPred.className = 'stat-value ' + (data.prediction === 'Up' ? 'trend-up' : 'trend-down');
        confPred.textContent = `Confidence: ${data.confidence}% • ${data.model_used || 'AI'}`;

        valSignal.textContent = data.signal;
        valSignal.className = 'stat-value signal-' + data.signal.toLowerCase();

        // Update Sentiment Card
        if (data.sentiment) {
            valSentiment.textContent = data.sentiment.label || '--';
            valSentiment.className = 'stat-value sentiment-' + (data.sentiment.label ? data.sentiment.label.toLowerCase() : 'neutral');
            descSentiment.textContent = `Score: ${data.sentiment.score} (${data.sentiment.count} articles)`;
        }

        // Render News
        if (data.headlines && data.headlines.length > 0) {
            newsSection.classList.remove('hidden');
            renderNews(data.headlines);
        } else {
            newsSection.classList.add('hidden');
        }

        // Render Chart
        renderChart(data);
    }

    function renderNews(headlines) {
        headlinesList.innerHTML = '';
        headlines.forEach(news => {
            const item = document.createElement('div');
            item.className = 'news-item';
            item.innerHTML = `
                <a href="${news.link}" target="_blank" class="news-link">
                    <div class="news-title">${news.title}</div>
                    <div class="news-date">${news.pubDate}</div>
                </a>
            `;
            headlinesList.appendChild(item);
        });
    }

    function renderChart(data) {
        const traceCandle = {
            x: data.historical.dates,
            close: data.historical.closes,
            decreasing: { line: { color: '#ff3366' } },
            increasing: { line: { color: '#00ff88' } },
            line: { color: 'rgba(31,119,180,1)' },
            type: 'candlestick',
            xaxis: 'x',
            yaxis: 'y',
            name: 'Price'
        };

        const traceSMA20 = {
            x: data.indicators.dates,
            y: data.indicators.sma20,
            type: 'scatter',
            mode: 'lines',
            line: { color: '#00d2ff', width: 1.5 },
            name: 'SMA 20'
        };

        const traceSMA50 = {
            x: data.indicators.dates,
            y: data.indicators.sma50,
            type: 'scatter',
            mode: 'lines',
            line: { color: '#ff00cc', width: 1.5 },
            name: 'SMA 50'
        };

        const plotData = [traceCandle, traceSMA20, traceSMA50];

        const layout = {
            paper_bgcolor: 'transparent',
            plot_bgcolor: 'transparent',
            font: { color: '#8b8b9e', family: 'Inter, sans-serif' },
            xaxis: {
                showgrid: true,
                gridcolor: 'rgba(255,255,255,0.05)',
                rangeslider: { visible: false }
            },
            yaxis: {
                showgrid: true,
                gridcolor: 'rgba(255,255,255,0.05)',
            },
            margin: { t: 10, r: 10, b: 40, l: 40 },
            showlegend: false,
            hovermode: 'x unified'
        };

        const config = { responsive: true, displayModeBar: false };

        Plotly.newPlot('mainChart', plotData, layout, config);
    }

    async function fetchPopularStocks() {
        try {
            const res = await fetch('/api/popular');
            const data = await res.json();

            const tbody = document.getElementById('popularStocksTbody');
            tbody.innerHTML = '';

            data.forEach(stock => {
                const tr = document.createElement('tr');
                const changeClass = stock.change >= 0 ? 'trend-up' : 'trend-down';
                const sign = stock.change >= 0 ? '+' : '';

                tr.innerHTML = `
                    <td><strong>${stock.symbol}</strong></td>
                    <td>$${stock.price.toFixed(2)}</td>
                    <td class="${changeClass}">${sign}${stock.change}%</td>
                `;
                tr.style.cursor = 'pointer';
                tr.addEventListener('click', () => {
                    searchInput.value = stock.symbol;
                    analyzeStock();
                });
                tbody.appendChild(tr);
            });
        } catch (e) {
            console.error("Failed fetching popular stocks", e);
        }
    }

    function showError(msg) {
        errorBanner.textContent = msg;
        errorBanner.classList.remove('hidden');
        chartPlaceholder.classList.remove('hidden');

        // Clear chart
        document.getElementById('mainChart').innerHTML = '';
        valPred.textContent = '--';
        valSignal.textContent = '--';
        confPred.textContent = 'Confidence: --%';
        valPred.className = 'stat-value';
        valSignal.className = 'stat-value';
    }

    // --- Stock Alert System ---
    const alertActions = document.getElementById('alertActions');
    const setAlertBtn = document.getElementById('setAlertBtn');
    const alertsSection = document.getElementById('alertsSection');
    const alertsList = document.getElementById('alertsList');
    const refreshAlertsBtn = document.getElementById('refreshAlerts');

    let currentStockData = null;

    if (setAlertBtn) setAlertBtn.addEventListener('click', handleSetAlert);
    if (refreshAlertsBtn) refreshAlertsBtn.addEventListener('click', loadUserAlerts);

    // Initial load of alerts if section exists
    if (alertsSection) {
        alertsSection.classList.remove('hidden');
        loadUserAlerts();
    }

    async function handleSetAlert() {
        if (!currentStockData) return;

        setAlertBtn.disabled = true;
        setAlertBtn.textContent = "Setting...";

        try {
            const res = await fetch('/api/alerts', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    symbol: currentStockData.symbol,
                    target_trend: currentStockData.signal
                })
            });
            const data = await res.json();

            if (!res.ok) throw new Error(data.error || "Failed to set alert.");

            showToast(`Alert set for ${currentStockData.symbol} ${currentStockData.signal} trend!`);
            loadUserAlerts();
        } catch (err) {
            console.error(err);
            showToast(err.message, true);
        } finally {
            setAlertBtn.disabled = false;
            setAlertBtn.textContent = "🔔 Set Alert";
        }
    }

    async function loadUserAlerts() {
        try {
            const res = await fetch('/api/alerts');
            const data = await res.json();
            if (!res.ok) return;

            alertsList.innerHTML = '';
            data.forEach(alert => {
                const item = document.createElement('div');
                item.className = 'alert-item';
                item.innerHTML = `
                    <div class="alert-info">
                        <h4>${alert.symbol}</h4>
                        <p>${alert.target_trend} Trend • Set ${alert.created_at}</p>
                    </div>
                    <button class="delete-alert" data-id="${alert.id}">✕</button>
                `;
                item.querySelector('.delete-alert').addEventListener('click', (e) => handleDeleteAlert(e, alert.id));
                alertsList.appendChild(item);
            });
        } catch (e) {
            console.error("Failed to load alerts", e);
        }
    }

    async function handleDeleteAlert(e, id) {
        const btn = e.currentTarget;
        btn.disabled = true;
        try {
            const res = await fetch(`/api/alerts/${id}`, { method: 'DELETE' });
            if (res.ok) {
                loadUserAlerts();
                showToast("Alert removed.");
            }
        } catch (err) {
            console.error(err);
        }
    }

    function showToast(msg, isError = false) {
        const toast = document.createElement('div');
        toast.className = 'toast';
        if (isError) toast.style.borderColor = '#ff3366';
        toast.textContent = msg;
        document.body.appendChild(toast);
        setTimeout(() => toast.remove(), 3000);
    }

    // Update prediction function to store data for alerts
    const originalUpdateDashboard = updateDashboard;
    updateDashboard = function(data) {
        currentStockData = data;
        if (alertActions) alertActions.classList.remove('hidden');
        originalUpdateDashboard(data);
        
        // Check for triggered alerts
        checkAlerts(data);
    };

    function checkAlerts(data) {
        // Simple client-side check for triggered alerts
        const items = alertsList.querySelectorAll('.alert-item');
        items.forEach(item => {
            const symbol = item.querySelector('h4').textContent;
            const info = item.querySelector('p').textContent;
            if (symbol === data.symbol && info.includes(data.signal)) {
                showToast(`🚀 ALERT TRIGGERED: ${data.symbol} is showing a ${data.signal} trend!`);
            }
        });
    }

    // --- Authentication Logic ---

    async function handleRegister(e) {
        e.preventDefault();
        const fullName = document.getElementById('regName').value;
        const email = document.getElementById('regEmail').value;
        const password = document.getElementById('regPassword').value;
        const confirmPassword = document.getElementById('regConfirmPassword').value;
        const btn = registerForm.querySelector('button[type="submit"]');

        if (password !== confirmPassword) {
            showAuthError(registerError, "Passwords do not match.");
            return;
        }

        btn.disabled = true;
        btn.textContent = "Registering...";
        registerError.classList.add('hidden');

        try {
            const res = await fetch('/api/auth/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ full_name: fullName, email, password })
            });
            const data = await res.json();

            if (!res.ok) throw new Error(data.error || "Registration failed.");

            // Success! Store email and show OTP modal
            registeredEmail = data.email;
            registerModal.classList.add('hidden');
            otpModal.classList.remove('hidden');

        } catch (err) {
            showAuthError(registerError, err.message);
        } finally {
            btn.disabled = false;
            btn.textContent = "Create Account";
        }
    }

    async function handleOTPVerify(e) {
        e.preventDefault();
        const otpCode = document.getElementById('otpCode').value;
        const btn = otpForm.querySelector('button[type="submit"]');

        btn.disabled = true;
        btn.textContent = "Verifying...";
        otpError.classList.add('hidden');

        try {
            const res = await fetch('/api/auth/verify-otp', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email: registeredEmail, otp_code: otpCode })
            });
            const data = await res.json();

            if (!res.ok) throw new Error(data.error || "Verification failed.");

            // Success! Go back to login
            otpModal.classList.add('hidden');
            loginModal.classList.remove('hidden');
            showAuthError(loginError, "Email verified! You can now log in.", true); // green generic msg

        } catch (err) {
            showAuthError(otpError, err.message);
        } finally {
            btn.disabled = false;
            btn.textContent = "Verify & Login";
        }
    }

    async function handleResendOTP(e) {
        e.preventDefault();
        const btn = e.target;
        btn.disabled = true;
        btn.textContent = "Resending...";

        try {
            const res = await fetch('/api/auth/resend-otp', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email: registeredEmail })
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || "Failed to resend.");
            showAuthError(otpError, "New OTP sent!", true);
        } catch (err) {
            showAuthError(otpError, err.message);
        } finally {
            setTimeout(() => {
                btn.disabled = false;
                btn.textContent = "Resend Code";
            }, 5000);
        }
    }

    async function handleLogin(e) {
        e.preventDefault();
        const email = document.getElementById('loginEmail').value;
        const password = document.getElementById('loginPassword').value;
        const btn = loginForm.querySelector('button[type="submit"]');

        btn.disabled = true;
        btn.textContent = "Signing in...";
        loginError.classList.add('hidden');

        try {
            const res = await fetch('/api/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });
            const data = await res.json();

            if (!res.ok) {
                if (data.requires_verification) {
                    registeredEmail = email; // setup for OTP
                    loginModal.classList.add('hidden');
                    otpModal.classList.remove('hidden');
                    // Auto resend OTP for convenience
                    fetch('/api/auth/resend-otp', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ email })
                    });
                    throw new Error("Please verify your email.");
                }
                throw new Error(data.error || "Login failed.");
            }

            // Success, reload page to get authenticated state
            window.location.reload();

        } catch (err) {
            if (err.message !== "Please verify your email.") {
                showAuthError(loginError, err.message);
            }
        } finally {
            btn.disabled = false;
            btn.textContent = "Sign In";
        }
    }

    function showAuthError(element, msg, isSuccess = false) {
        element.textContent = msg;
        element.classList.remove('hidden');
        if (isSuccess) {
            element.style.color = '#00ff88';
            element.style.backgroundColor = 'rgba(0, 255, 136, 0.1)';
        } else {
            element.style.color = '#ff3366';
            element.style.backgroundColor = 'rgba(255, 51, 102, 0.1)';
        }
    }

    // --- Portfolio Simulation ---
    const portfolioBalance = document.getElementById('portfolioBalance');
    const tradeSymbol = document.getElementById('tradeSymbol');
    const tradeQty = document.getElementById('tradeQty');
    const buyBtn = document.getElementById('buyBtn');
    const sellBtn = document.getElementById('sellBtn');
    const tradeMessage = document.getElementById('tradeMessage');
    const holdingsList = document.getElementById('holdingsList');
    const tradeHistoryBody = document.getElementById('tradeHistoryBody');

    if (buyBtn) buyBtn.addEventListener('click', () => executeTrade('BUY'));
    if (sellBtn) sellBtn.addEventListener('click', () => executeTrade('SELL'));

    // Load portfolio on page load
    loadPortfolio();

    async function executeTrade(action) {
        const symbol = tradeSymbol.value.trim().toUpperCase();
        const quantity = parseInt(tradeQty.value);

        if (!symbol || !quantity || quantity <= 0) {
            showTradeMessage('Enter a valid symbol and quantity.', true);
            return;
        }

        buyBtn.disabled = true;
        sellBtn.disabled = true;

        try {
            const res = await fetch('/api/portfolio/trade', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ symbol, action, quantity })
            });
            const data = await res.json();

            if (!res.ok) throw new Error(data.error || 'Trade failed.');

            showTradeMessage(data.message, false);
            portfolioBalance.textContent = `$${data.new_balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}`;
            loadPortfolio();
        } catch (err) {
            showTradeMessage(err.message, true);
        } finally {
            buyBtn.disabled = false;
            sellBtn.disabled = false;
        }
    }

    async function loadPortfolio() {
        try {
            const res = await fetch('/api/portfolio');
            const data = await res.json();
            if (!res.ok) return;

            portfolioBalance.textContent = `$${data.cash_balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}`;

            // Render holdings
            if (Object.keys(data.holdings).length > 0) {
                holdingsList.innerHTML = '';
                for (const [sym, qty] of Object.entries(data.holdings)) {
                    const tag = document.createElement('div');
                    tag.className = 'holding-tag';
                    tag.innerHTML = `<strong>${sym}</strong> <span>${qty} shares</span>`;
                    holdingsList.appendChild(tag);
                }
            } else {
                holdingsList.innerHTML = '<p class="empty-state">No positions yet. Make your first trade!</p>';
            }

            // Load trade history
            loadTradeHistory();
        } catch (e) {
            console.error('Failed to load portfolio', e);
        }
    }

    async function loadTradeHistory() {
        try {
            const res = await fetch('/api/portfolio/history');
            const data = await res.json();
            if (!res.ok) return;

            tradeHistoryBody.innerHTML = '';
            data.forEach(t => {
                const tr = document.createElement('tr');
                const actionClass = t.action === 'BUY' ? 'trend-up' : 'trend-down';
                tr.innerHTML = `
                    <td class="${actionClass}"><strong>${t.action}</strong></td>
                    <td>${t.symbol}</td>
                    <td>${t.quantity}</td>
                    <td>$${t.price.toFixed(2)}</td>
                    <td>$${t.total.toFixed(2)}</td>
                `;
                tradeHistoryBody.appendChild(tr);
            });
        } catch (e) {
            console.error('Failed to load trade history', e);
        }
    }

    function showTradeMessage(msg, isError) {
        tradeMessage.textContent = msg;
        tradeMessage.classList.remove('hidden');
        tradeMessage.style.color = isError ? '#ff3366' : '#00ff88';
        tradeMessage.style.background = isError ? 'rgba(255,51,102,0.1)' : 'rgba(0,255,136,0.1)';
        setTimeout(() => tradeMessage.classList.add('hidden'), 4000);
    }

    // Auto-fill trade symbol when stock is analyzed
    const origUpdate = updateDashboard;
    updateDashboard = function(data) {
        origUpdate(data);
        if (tradeSymbol) tradeSymbol.value = data.symbol;
    };
});
