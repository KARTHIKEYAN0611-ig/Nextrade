import yfinance as yf
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from sklearn.metrics import accuracy_score
import joblib
import os
from datetime import datetime, timedelta
import pytz
from ta.trend import SMAIndicator, EMAIndicator, MACD
from ta.momentum import RSIIndicator
from ta.volatility import AverageTrueRange, BollingerBands

class StockPredictor:
    def __init__(self, model_dir='models'):
        self.model_dir = model_dir
        self.features = ['Open', 'High', 'Low', 'Close', 'Volume', 'SMA_20', 'SMA_50', 
                         'EMA_20', 'RSI', 'MACD', 'MACD_Signal', 'ATR', 'BB_High', 'BB_Low', 'Daily_Return']
        
        if not os.path.exists(self.model_dir):
            os.makedirs(self.model_dir)

    def fetch_data(self, symbol, period="5y", interval="1d"):
        """Fetch historical stock data with interval support."""
        symbol = symbol.upper()
        
        # Local cache check (optional, but keep for robustness)
        # Note: Local CSVs might not have the correct interval, so we prioritize yfinance for specific intervals
        if interval == "1d":
            possible_paths = [
                os.path.join('data', f"{symbol}.csv"),
                os.path.join('data', 'stocks', f"{symbol}.csv")
            ]
            for csv_path in possible_paths:
                if os.path.exists(csv_path):
                    try:
                        df = pd.read_csv(csv_path)
                        df.columns = [c.title() if c.lower() in ['date', 'open', 'high', 'low', 'close', 'volume'] else c for c in df.columns]
                        date_col = next((c for c in df.columns if c.lower() == 'date'), None)
                        if date_col:
                            df[date_col] = pd.to_datetime(df[date_col])
                            df.set_index(date_col, inplace=True)
                        if 'Adj Close' in df.columns:
                            df['Close'] = df['Adj Close']
                        df.sort_index(inplace=True)
                        return df
                    except Exception as e:
                        print(f"Error reading {csv_path}: {e}")
        
        try:
            stock = yf.Ticker(symbol)
            # Adjust period based on interval if not specified
            if interval in ["1m", "5m", "15m"] and period == "5y":
                period = "1mo" # yfinance limit for intra-day
            
            df = stock.history(period=period, interval=interval)
            if df.empty: return None
            if df.index.tz is not None:
                df.index = df.index.tz_localize(None)
            return df
        except Exception as e:
            print(f"Error fetching {symbol} ({interval}): {e}")
            return None

    def preprocess(self, df):
        """Clean and add professional technical indicators using 'ta' library."""
        if df is None or df.empty: return None
        
        df = df.copy()
        df = df.drop(columns=['Dividends', 'Stock Splits', 'Capital Gains'], errors='ignore')

        # SMA & EMA
        df['SMA_20'] = SMAIndicator(close=df['Close'], window=20).sma_indicator()
        df['SMA_50'] = SMAIndicator(close=df['Close'], window=50).sma_indicator()
        df['EMA_20'] = EMAIndicator(close=df['Close'], window=20).ema_indicator()
        
        # MACD
        macd = MACD(close=df['Close'], window_slow=26, window_fast=12, window_sign=9)
        df['MACD'] = macd.macd()
        df['MACD_Signal'] = macd.macd_signal()
        
        # Volatility
        df['ATR'] = AverageTrueRange(high=df['High'], low=df['Low'], close=df['Close'], window=14).average_true_range()
        bb = BollingerBands(close=df['Close'], window=20, window_dev=2)
        df['BB_High'] = bb.bollinger_hband()
        df['BB_Low'] = bb.bollinger_lband()
        
        # Momentum
        df['RSI'] = RSIIndicator(close=df['Close'], window=14).rsi()
        
        df['Daily_Return'] = df['Close'].pct_change()

        return df.dropna()

    def preprocess_rl(self, df):
        """Minimal preprocessing for RL state space (Raw OHLCV + Key Indicators)."""
        df = self.preprocess(df)
        if df is None: return None
        # Normalize/Scale if necessary, but SB3 algorithms handle some scaling
        return df

    def _create_target(self, df):
        df = df.copy()
        df['Target'] = np.where(df['Close'].shift(-1) > df['Close'], 1, 0)
        return df.dropna()

    def train(self, symbol, interval="1d"):
        """Train Ensemble logic (RF + XGB)."""
        df = self.fetch_data(symbol, interval=interval)
        if df is None: return None, 0.0, ""
        
        processed = self.preprocess(df)
        if processed is None: return None, 0.0, ""
        
        data = self._create_target(processed)
        X = data[self.features]
        y = data['Target']

        split_idx = int(len(data) * 0.8)
        X_train, X_test = X.iloc[:split_idx], X.iloc[split_idx:]
        y_train, y_test = y.iloc[:split_idx], y.iloc[split_idx:]

        rf = RandomForestClassifier(n_estimators=100, random_state=42)
        rf.fit(X_train, y_train)
        rf_acc = accuracy_score(y_test, rf.predict(X_test))

        xgb = XGBClassifier(n_estimators=100, random_state=42, eval_metric='logloss')
        xgb.fit(X_train, y_train)
        xgb_acc = accuracy_score(y_test, xgb.predict(X_test))

        if xgb_acc >= rf_acc:
            best_model, best_acc, m_type = xgb, xgb_acc, "XGBoost"
        else:
            best_model, best_acc, m_type = rf, rf_acc, "RandomForest"
        
        joblib.dump({'model': best_model, 'type': m_type, 'acc': best_acc}, 
                    os.path.join(self.model_dir, f"{symbol}_{interval}_model.joblib"))
        return best_model, best_acc, m_type

    def get_prediction(self, symbol, interval="1d"):
        """Final prediction with support for intervals."""
        period = "1y" if interval == "1d" else "1mo"
        raw_df = self.fetch_data(symbol, period=period, interval=interval)
        if raw_df is None: return {"error": "Invalid symbol or interval"}

        processed = self.preprocess(raw_df)
        if processed is None or processed.empty: return {"error": "Insufficient data for indicators"}

        model_path = os.path.join(self.model_dir, f"{symbol}_{interval}_model.joblib")
        if os.path.exists(model_path):
            saved = joblib.load(model_path)
            model, model_type = saved['model'], saved['type']
        else:
            model, _, model_type = self.train(symbol, interval=interval)
            if model is None: return {"error": "Training failed"}

        latest_row = processed[self.features].iloc[-1:]
        pred = model.predict(latest_row)[0]
        probs = model.predict_proba(latest_row)[0]
        confidence = float(max(probs))

        tz_ist = pytz.timezone('Asia/Kolkata')
        ist_now = datetime.now(tz_ist).strftime('%Y-%m-%d %H:%M:%S')

        signal = "HOLD"
        if pred == 1 and confidence >= 0.55: signal = "BUY"
        elif pred == 0 and confidence >= 0.55: signal = "SELL"

        last_price = float(raw_df['Close'].iloc[-1])
        atr_val = float(processed['ATR'].iloc[-1])
        target_move_pct = (atr_val / last_price) * 100

        return {
            "symbol": symbol,
            "interval": interval,
            "prediction": "Up" if pred == 1 else "Down",
            "confidence": round(confidence * 100, 2),
            "signal": signal,
            "model": model_type,
            "timestamp_ist": ist_now,
            "last_price": round(last_price, 2),
            "target_move_pct": round(target_move_pct, 2)
        }

