from flask import Blueprint, jsonify, request, session, url_for, current_app
from werkzeug.security import generate_password_hash, check_password_hash
from models import db, User, OTPVerification
from datetime import datetime, timedelta
import random
import re
from flask_mail import Mail, Message

# We'll initialize Mail in app.py and import it, but we can also use current_app extensions
auth_bp = Blueprint('auth_routes', __name__)
mail = Mail()

def generate_otp():
    """Generates a 6-digit random OTP."""
    return str(random.randint(100000, 999999))

def send_otp_email(user_email, otp_code):
    """Sends the OTP email."""
    try:
        msg = Message("Your OTP Verification Code",
                      sender=current_app.config.get('MAIL_USERNAME', 'noreply@tradingplatform.local'),
                      recipients=[user_email])
        msg.body = f"Your one-time password (OTP) is: {otp_code}\n\nThis code will expire in 10 minutes."
        
        # In development without real SMTP, we might print to console as fallback if real email fails
        if current_app.config.get('MAIL_SERVER'):
            mail.send(msg)
        else:
            print(f"--- MOCK EMAIL --- To: {user_email} | OTP: {otp_code} ---")
            
    except Exception as e:
        print(f"Failed to send email: {e}")
        # Always print to console in case of development error
        print(f"--- MOCK EMAIL FALLBACK --- To: {user_email} | OTP: {otp_code} ---")

def validate_password_complexity(password):
    """Enforces specific password complexity: 
       - Exactly 8 characters
       - At least 1 uppercase letter
       - At least 1 number
       - At least 1 special character
    """
    if len(password) != 8:
        return False
    if not re.search(r"[A-Z]", password):
        return False
    if not re.search(r"[0-9]", password):
        return False
    if not re.search(r"[!@#$%^&*(),.?\":{}|<>]", password):
        return False
    return True

@auth_bp.route('/api/auth/register', methods=['POST'])
def register():
    data = request.get_json()
    if not data:
        return jsonify({"error": "Invalid request payload"}), 400

    full_name = data.get('full_name')
    email = data.get('email')
    password = data.get('password')

    if not full_name or not email or not password:
        return jsonify({"error": "All fields are required"}), 400

    # Ensure email is unique
    existing_user = User.query.filter_by(email=email).first()
    if existing_user:
        if existing_user.auth_provider == 'google':
             return jsonify({"error": "This email is registered with Google Sign-In. Try logging in with Google."}), 400
        return jsonify({"error": "Email already registered."}), 400

    if not validate_password_complexity(password):
        return jsonify({"error": "Password must be at least 8 characters long and contain both letters and numbers."}), 400

    # Create new user
    hashed_pwd = generate_password_hash(password)
    new_user = User(
        full_name=full_name,
        email=email,
        password_hash=hashed_pwd,
        auth_provider='local',
        is_verified=False
    )
    db.session.add(new_user)
    db.session.commit()

    # Generate and save OTP
    otp_code = generate_otp()
    expires_at = datetime.utcnow() + timedelta(minutes=10)
    
    otp_record = OTPVerification(
        user_id=new_user.id,
        otp_code=otp_code,
        expires_at=expires_at
    )
    db.session.add(otp_record)
    db.session.commit()

    # Send Email
    send_otp_email(new_user.email, otp_code)

    return jsonify({"message": "Registration successful. Please check your email for the OTP.", "email": email}), 201


@auth_bp.route('/api/auth/verify-otp', methods=['POST'])
def verify_otp():
    data = request.get_json()
    email = data.get('email')
    otp_code = data.get('otp_code')

    if not email or not otp_code:
        return jsonify({"error": "Email and OTP are required"}), 400

    user = User.query.filter_by(email=email).first()
    if not user:
        return jsonify({"error": "User not found"}), 404

    if user.is_verified:
        return jsonify({"message": "User is already verified"}), 200

    # Find valid OTP record
    otp_record = OTPVerification.query.filter_by(user_id=user.id, otp_code=otp_code).order_by(OTPVerification.created_at.desc()).first()

    if not otp_record:
        return jsonify({"error": "Invalid OTP code"}), 400

    if otp_record.is_expired():
        return jsonify({"error": "OTP has expired. Please request a new one."}), 400

    # Verify user
    user.is_verified = True
    
    # Delete all OTPs for this user as they are no longer needed
    OTPVerification.query.filter_by(user_id=user.id).delete()
    
    db.session.commit()

    return jsonify({"message": "Email verified successfully. You can now log in."}), 200


@auth_bp.route('/api/auth/resend-otp', methods=['POST'])
def resend_otp():
    data = request.get_json()
    email = data.get('email')

    if not email:
        return jsonify({"error": "Email is required"}), 400

    user = User.query.filter_by(email=email).first()
    if not user:
        return jsonify({"error": "User not found"}), 404

    if user.is_verified:
        return jsonify({"error": "User is already verified"}), 400

    # Generate new OTP
    otp_code = generate_otp()
    expires_at = datetime.utcnow() + timedelta(minutes=10)
    
    otp_record = OTPVerification(
        user_id=user.id,
        otp_code=otp_code,
        expires_at=expires_at
    )
    db.session.add(otp_record)
    db.session.commit()

    # Send Email
    send_otp_email(user.email, otp_code)

    return jsonify({"message": "A new OTP has been sent to your email."}), 200


@auth_bp.route('/api/auth/login', methods=['POST'])
def login():
    data = request.get_json()
    email = data.get('email')
    password = data.get('password')

    if not email or not password:
        return jsonify({"error": "Email and password are required"}), 400

    user = User.query.filter_by(email=email).first()

    if not user or user.auth_provider != 'local':
        return jsonify({"error": "Invalid credentials or account is registered via Google."}), 401

    if not check_password_hash(user.password_hash, password):
        return jsonify({"error": "Invalid credentials"}), 401

    if not user.is_verified:
        # Prevent login, suggest resending OTP
        return jsonify({"error": "Email is not verified. Please verify your email first.", "requires_verification": True}), 403

    # Set session
    session['user'] = {
        'id': user.id,
        'email': user.email,
        'name': user.full_name,
        'provider': user.auth_provider
    }

    return jsonify({"message": "Login successful", "user": session['user']}), 200
