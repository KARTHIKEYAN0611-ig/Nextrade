from flask import Flask, jsonify, request, render_template, redirect, url_for, session
from flask_cors import CORS
from authlib.integrations.flask_client import OAuth
from dotenv import load_dotenv
import os
import yfinance as yf
from models import db, User
from routes.auth_routes import auth_bp, mail

# Load environment variables
load_dotenv()

from ml.engine import StockPredictor
from ml.rl_engine import RLPredictor

app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "dev_secret")
CORS(app)

# Database
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'instance', 'trading.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)
mail.init_app(app)

# Register Blueprints
app.register_blueprint(auth_bp)

with app.app_context():
    db.create_all()

predictor = StockPredictor()
rl_predictor = RLPredictor()

# --- OAuth 2.0 Setup ---
oauth = OAuth(app)
google = oauth.register(
    name='google',
    client_id=os.getenv("GOOGLE_CLIENT_ID"),
    client_secret=os.getenv("GOOGLE_CLIENT_SECRET"),
    server_metadata_url='https://accounts.google.com/.well-known/openid-configuration',
    client_kwargs={'scope': 'openid email profile'}
)

@app.route('/')
def index():
    return render_template('index.html', user=session.get('user'))

@app.route('/analyze/<symbol>')
def analyze(symbol):
    interval = request.args.get('interval', '1d')
    return render_template('results.html', symbol=symbol.upper(), interval=interval, user=session.get('user'))

@app.route('/api/predict/<symbol>')
def get_prediction(symbol):
    interval = request.args.get('interval', '1d')
    result = predictor.get_prediction(symbol.upper(), interval=interval)
    if "error" in result:
        return jsonify(result), 400
    return jsonify(result)

@app.route('/api/v2/predict_rl/<symbol>')
def get_rl_prediction(symbol):
    interval = request.args.get('interval', '1d')
    result = rl_predictor.get_signal(symbol.upper(), interval=interval)
    if "error" in result:
        return jsonify(result), 400
    return jsonify(result)

@app.route('/api/v2/train_rl/<symbol>')
def train_rl(symbol):
    # This might take some time, in a production app we'd use a task queue like Celery
    # For now, we'll do it synchronously or with limited timesteps
    interval = request.args.get('interval', '1d')
    success = rl_predictor.train(symbol.upper(), interval=interval, total_timesteps=5000)
    if success:
        return jsonify({"status": "success", "message": f"RL Model trained for {symbol} ({interval})"})
    return jsonify({"status": "error", "message": "Training failed"}), 500

@app.route('/auth')
def auth_page():
    if session.get('user'):
        return redirect(url_for('index'))
    return render_template('auth.html')

@app.route('/login')
def login():
    redirect_uri = url_for('auth_callback', _external=True)
    return google.authorize_redirect(redirect_uri)

@app.route('/auth/callback')
def auth_callback():
    token = google.authorize_access_token()
    user_info = token['userinfo']
    email = user_info.get('email')
    user = User.query.filter_by(email=email).first()
    if not user:
        user = User(full_name=user_info.get('name'), email=email, auth_provider='google', is_verified=True)
        db.session.add(user)
        db.session.commit()
    session['user'] = {'id': user.id, 'email': user.email, 'name': user.full_name}
    return redirect('/')

@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect('/')

@app.route('/api/popular')
def popular_stocks():
    symbols = ['AAPL', 'TSLA', 'GOOGL', 'AMZN', 'MSFT', 'RELIANCE.NS']
    data = []
    for sym in symbols:
        try:
            ticker = yf.Ticker(sym)
            hist = ticker.history(period="2d")
            if not hist.empty and len(hist) >= 2:
                last_price = hist['Close'].iloc[-1]
                prev_price = hist['Close'].iloc[-2]
                change = ((last_price - prev_price) / prev_price) * 100
                data.append({"symbol": sym, "price": round(last_price, 2), "change": round(change, 2)})
        except: continue
    return jsonify(data)

if __name__ == '__main__':
    app.run(debug=True, port=5000)
