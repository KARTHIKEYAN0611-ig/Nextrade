import pytest
from app import app

from unittest.mock import patch
import pandas as pd

@pytest.fixture
def client():
    app.config['TESTING'] = True
    with app.test_client() as client:
        yield client

def test_index_page(client):
    rv = client.get('/')
    assert rv.status_code == 200
    assert b"NexTrade" in rv.data

@patch('app.yf.Ticker')
def test_popular_api(mock_ticker, client):
    # Setup mock dataframe with 2 days of data
    mock_hist = pd.DataFrame({
        'Close': [100.0, 105.0]
    })
    mock_ticker.return_value.history.return_value = mock_hist

    rv = client.get('/api/popular')
    assert rv.status_code == 200
    data = rv.get_json()
    assert isinstance(data, list)
    assert len(data) > 0
    assert data[0]['symbol'] == 'AAPL'
    assert data[0]['price'] == 105.0
    assert data[0]['change'] == 5.0
    
# Not testing /api/predict in simple tests because it requires downloading real data, 
# which makes the test flaky and slow. We can mock it for a real integration test,
# but for now, testing the availability of endpoints.
