document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const otpForm = document.getElementById('otpForm');
    
    const showRegister = document.getElementById('showRegister');
    const showLogin = document.getElementById('showLogin');
    
    const loginView = document.getElementById('loginView');
    const registerView = document.getElementById('registerView');
    const otpView = document.getElementById('otpView');
    
    const statusMsg = document.getElementById('statusMsg');
    
    // Toggle between Login and Register
    if (showRegister) {
        showRegister.addEventListener('click', (e) => {
            e.preventDefault();
            loginView.classList.add('hidden');
            registerView.classList.remove('hidden');
            clearStatus();
        });
    }
    
    if (showLogin) {
        showLogin.addEventListener('click', (e) => {
            e.preventDefault();
            registerView.classList.add('hidden');
            loginView.classList.remove('hidden');
            clearStatus();
        });
    }

    function showStatus(msg, type = 'error') {
        statusMsg.textContent = msg;
        statusMsg.className = `auth-status ${type}`;
    }

    function clearStatus() {
        statusMsg.textContent = '';
        statusMsg.className = 'auth-status hidden';
    }

    // Handle Registration
    if (registerForm) {
        registerForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(registerForm);
            const data = Object.fromEntries(formData.entries());

            // Password Matching
            if (data.password !== data.confirm_password) {
                showStatus("Passwords do not match");
                return;
            }

            // Password Complexity: 8 chars, 1 caps, 1 number, 1 special
            const passRegex = /^(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*(),.?":{}|<>]).{8}$/;
            if (!passRegex.test(data.password)) {
                showStatus("Password must be exactly 8 characters with at least 1 uppercase, 1 number, and 1 special character.");
                return;
            }

            try {
                const response = await fetch('/api/auth/register', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        full_name: `${data.first_name} ${data.last_name}`,
                        email: data.email,
                        password: data.password
                    })
                });

                const result = await response.json();
                if (response.ok) {
                    registerView.classList.add('hidden');
                    otpView.classList.remove('hidden');
                    document.getElementById('otpEmailDisplay').textContent = data.email;
                    showStatus("Please check your email for the OTP.", 'success');
                } else {
                    showStatus(result.error || "Registration failed");
                }
            } catch (err) {
                showStatus("An error occurred. Please try again.");
            }
        });
    }

    // Handle Login
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(loginForm);
            const data = Object.fromEntries(formData.entries());

            try {
                const response = await fetch('/api/auth/login', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });

                const result = await response.json();
                if (response.ok) {
                    window.location.href = '/';
                } else {
                    if (result.requires_verification) {
                         // Show OTP screen if not verified
                         loginView.classList.add('hidden');
                         otpView.classList.remove('hidden');
                         document.getElementById('otpEmailDisplay').textContent = data.email;
                         showStatus(result.error, 'error');
                    } else {
                        showStatus(result.error || "Login failed");
                    }
                }
            } catch (err) {
                showStatus("An error occurred. Please try again.");
            }
        });
    }

    // Handle OTP
    if (otpForm) {
        otpForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const otpCode = document.getElementById('otpCode').value;
            const email = document.getElementById('otpEmailDisplay').textContent;

            try {
                const response = await fetch('/api/auth/verify-otp', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email, otp_code: otpCode })
                });

                const result = await response.json();
                if (response.ok) {
                    showStatus("Verified! Redirecting to login...", 'success');
                    setTimeout(() => {
                        otpView.classList.add('hidden');
                        loginView.classList.remove('hidden');
                        clearStatus();
                    }, 2000);
                } else {
                    showStatus(result.error || "Verification failed");
                }
            } catch (err) {
                showStatus("An error occurred. Please try again.");
            }
        });
    }

    // Toggle Password Visibility
    window.togglePasswordVisibility = function(id) {
        const input = document.getElementById(id);
        const icon = input.nextElementSibling;
        if (input.type === 'password') {
            input.type = 'text';
            icon.textContent = '👁️';
        } else {
            input.type = 'password';
            icon.textContent = '👁️‍🗨️';
        }
    };
});
