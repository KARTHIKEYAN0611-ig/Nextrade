# NexTrade | Technical Implementation Overview

NexTrade is a high-performance, full-stack AI platform designed to provide actionable stock market predictions and technical analysis. This document details the architecture, technologies, and implementation specifics of the project.

---

## 🏗️ System Architecture

The project follows a modular **Flask (Python)** backend architecture with a decoupled **Machine Learning Engine** and a dynamic **JavaScript-driven Frontend**.

```mermaid
graph TD
    User((User)) -->|Browser| Frontend[Frontend - HTML/CSS/JS/Plotly]
    Frontend -->|REST API| Flask[Flask Backend]
    Flask -->|Logic| Auth[Auth Service - OAuth/OTP]
    Flask -->|Analysis| MLEngine[ML Engine - Random Forest]
    Flask -->|Persistence| SQL[SQLite DB - SQLAlchemy]
    MLEngine -->|Data| YF[Yahoo Finance / CSV]
```

---

## 🛠️ Technology Stack

### Backend & Core Logic
- **Framework**: Flask (Python)
- **Database**: SQLite (managed via SQLAlchemy)
- **ML Framework**: Scikit-learn (Random Forest Classifier)
- **Data Processing**: Pandas, NumPy
- **External Data**: Yahoo Finance API (`yfinance`)
- **Authentication**: Authlib (Google OAuth), Flask-Mail (OTP Verification)

### Frontend & UI/UX
- **Styling**: Vanilla CSS with **Glassmorphism** design principles.
- **Visualization**: **Plotly.js** for interactive candlestick and indicator charts.
- **Interactivity**: Asynchronous AJAX (Fetch API) for real-time model training and inference.
- **Typography**: Modern fonts (Inter & Outfit) via Google Fonts.

---

## 🧠 Machine Learning Implementation

The core intelligence resides in `ml/engine.py`, which implements the `StockPredictor` class.

### 1. Data Acquisition & Preprocessing
- **Source**: Automatically fetches 5 years of historical data based on the ticker symbol.
- **Local Data Support**: Checks the `data/` directory for `{SYMBOL}.csv` before fetching from the cloud.
- **Technical Indicators**: Calculates dynamic features for the model:
    - **SMA (Simple Moving Average)**: 20-day and 50-day windows.
    - **Bollinger Bands**: Upper and Lower bands (2x Standard Deviation).
    - **RSI (Relative Strength Index)**: 14-day momentum oscillator.
    - **Daily Returns**: Percentage price changes.

### 2. Model Training
- **Algorithm**: `RandomForestClassifier` (100 estimators, max depth 10).
- **Target**: A binary classification (1 if tomorrow's price > today's price, else 0).
- **Validation**: Uses a **Temporal Split** (80% training, 20% testing) to ensure results respect the timeline of financial data.
- **Persistence**: Models are serialized as `.joblib` files in the `models/` directory for fast subsequent inference.

### 3. Signal Generation
Predictions are converted into actionable advice:
- **BUY**: Model predicts "Up" with $\geq 60\%$ confidence.
- **SELL**: Model predicts "Down" with $\geq 60\%$ confidence.
- **HOLD**: Prediction confidence is below the threshold ($< 60\%$).

---

## 🔑 Authentication & Security

NexTrade implements a dual-method authentication system:

1.  **Local Authentication**:
    - **Complexity**: Enforces 8-character passwords with uppercase, numbers, and symbols.
    - **Verification**: Mandatory **OTP (One-Time Password)** sent via email upon registration.
2.  **Google OAuth 2.0**:
    - Users can sign in seamlessly with their Google accounts.
    - OAuth users are automatically marked as verified.
3.  **Session Management**: Secure session handling for protected API endpoints (like stock alerts).

---

## 🔔 Key Features Implementation

### **Stock Alerts**
Users can subscribe to specific stock trends (e.g., "Alert me when AAPL turns 'Buy'"). The backend stores these in the `stock_alerts` table and provides a management interface via the dashboard.

### **Interactive Dashboard**
- **Dynamic Charting**: Toggles between Price charts and Moving Averages.
- **Automated Workflow**: When a user searches for a ticker, the system:
    1. Checks if a trained model exists.
    2. Trains a new model if necessary.
    3. Runs inference on latest data.
    4. Renders the interactive chart and AI verdict instantly.

---

## 📂 Project Structure Refined

- **`app.py`**: Entry point and API routing.
- **`models.py`**: Database schema (Users, OTP, Alerts).
- **`ml/engine.py`**: Unified logic for data fetching, ML training, and predictions.
- **`routes/auth_routes.py`**: Authentication logic for local login/OTP.
- **`static/`**: Styles (CSS) and Frontend logic (JS).
- **`templates/`**: HTML views (Dashboard, Login, Terms).
- **`data/`**: Storage for local CSV datasets.
- **`models/`**: Storage for trained model files.
