import requests
from bs4 import BeautifulSoup
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import time

class SentimentEngine:
    def __init__(self):
        self.analyzer = SentimentIntensityAnalyzer()
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }

    def get_news_sentiment(self, symbol):
        """
        Fetches recent news for a symbol and calculates aggregate sentiment.
        Returns a dictionary with sentiment score and news count.
        """
        # Using Google News RSS feed for the symbol
        rss_url = f"https://news.google.com/rss/search?q={symbol}+stock&hl=en-US&gl=US&ceid=US:en"
        
        try:
            response = requests.get(rss_url, headers=self.headers, timeout=10)
            if response.status_code != 200:
                return {"score": 0, "count": 0, "status": "error", "message": "Failed to fetch news"}

            soup = BeautifulSoup(response.content, 'xml')
            items = soup.find_all('item')[:10]  # Get top 10 news items
            
            if not items:
                return {"score": 0, "count": 0, "status": "no_news"}

            total_score = 0
            for item in items:
                title = item.title.text
                sentiment = self.analyzer.polarity_scores(title)
                total_score += sentiment['compound']

            average_score = total_score / len(items)
            
            # Map score to labels
            label = "Neutral"
            if average_score > 0.1: label = "Bullish"
            elif average_score < -0.1: label = "Bearish"

            return {
                "score": round(average_score, 2),
                "label": label,
                "count": len(items),
                "status": "success"
            }
        except Exception as e:
            print(f"Sentiment Analysis Error for {symbol}: {e}")
            return {"score": 0, "count": 0, "status": "error", "message": str(e)}

    def get_news_headlines(self, symbol):
        """Returns a list of top 5 news headlines for display."""
        rss_url = f"https://news.google.com/rss/search?q={symbol}+stock&hl=en-US&gl=US&ceid=US:en"
        try:
            response = requests.get(rss_url, headers=self.headers, timeout=10)
            soup = BeautifulSoup(response.content, 'xml')
            items = soup.find_all('item')[:5]
            
            headlines = []
            for item in items:
                headlines.append({
                    "title": item.title.text,
                    "link": item.link.text,
                    "pubDate": item.pubDate.text
                })
            return headlines
        except Exception:
            return []
